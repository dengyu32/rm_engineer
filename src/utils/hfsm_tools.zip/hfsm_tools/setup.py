from setuptools import setup

package_name = 'hfsm_tools'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/hook', ['resource/ament_prefix_path.dsv']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='dev',
    maintainer_email='dev@local',
    description='Tools for HFSM testing and automation.',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'hfsm_intent_runner = hfsm_tools.hfsm_intent_runner:main',
        ],
    },
)
